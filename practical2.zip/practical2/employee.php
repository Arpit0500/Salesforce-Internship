<?php
$host = 'localhost';
$dbname = 'db1';
$user = 'postgres';
$password = 'Pass@word';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deptName = $_POST['dept_name'];

    $conn = pg_connect("host=$host dbname=$dbname user=$user password=$password");
    if (!$conn) {
        die("Connection failed: " . pg_last_error());
    }

    $query = "SELECT COUNT(e.eno) AS employee_count 
              FROM Emp e
              JOIN Dept d ON e.dno = d.dno
              WHERE d.dname ILIKE $1"; // ILIKE is used for case-insensitive matching in PostgreSQL

    $result = pg_prepare($conn, "count_query", $query);
    if (!$result) {
        die("Query preparation failed: " . pg_last_error($conn));
    }
    
    $result = pg_execute($conn, "count_query", array($deptName));
    if (!$result) {
        die("Query execution failed: " . pg_last_error($conn));
    }

    $row = pg_fetch_assoc($result);
    $count = $row['employee_count'];

    echo "<h3>Result:</h3>";
    echo "The number of employees in the '" . htmlspecialchars($deptName) . "' department is: <strong>" . $count . "</strong>";

    pg_close($conn);
} else {
    // If accessed directly without POST method
    echo "Please use the form to enter a department name.";
}
?>

Postgresql steps
-- Create the Dept table
CREATE TABLE Dept (
    dno INT PRIMARY KEY,
    dname VARCHAR(100) NOT NULL,
    location VARCHAR(100)
);

-- Create the Emp table with a foreign key to Dept
CREATE TABLE Emp (
    eno INT PRIMARY KEY,
    ename VARCHAR(100) NOT NULL,
    designation VARCHAR(100),
    salary DECIMAL(10, 2),
    dno INT REFERENCES Dept(dno)
);

-- Insert sample data into Dept
INSERT INTO Dept (dno, dname, location) VALUES
(1, 'HR', 'New York'),
(2, 'Sales', 'Los Angeles'),
(3, 'IT', 'San Francisco');

-- Insert sample data into Emp
INSERT INTO Emp (eno, ename, designation, salary, dno) VALUES
(101, 'John Doe', 'Manager', 60000.00, 1),
(102, 'Jane Smith', 'Clerk', 40000.00, 1),
(103, 'Mike Johnson', 'Analyst', 50000.00, 2),
(104, 'Emily Davis', 'Developer', 70000.00, 3),
(105, 'Chris Brown', 'Developer', 75000.00, 3);

