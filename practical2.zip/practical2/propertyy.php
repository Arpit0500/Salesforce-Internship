
$host = "localhost";
$dbname = "db1";
$user = "postgres";
$password = "Pass@word";

$db = pg_connect("host=$host dbname=$dbname user=$user password=$password");

if (!$db) {
    echo "Error : Unable to open database\n";
    exit;
}

$ownerName = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ownerName = $_POST['owner_name'];
}
if (!empty($ownerName)) {
        
        $sql = "SELECT no, description, area 
                FROM properties 
                
                WHERE owner_name = '" . pg_escape_string($ownerName) . "'";
        
        $result = pg_query($db, $sql);

        if (pg_num_rows($result) > 0) {
            echo "<h3>Properties owned by: $ownerName</h3>";
            echo "<table border='1'><tr><th>No</th><th>Description</th><th>Area</th></tr>";
            while ($row = pg_fetch_assoc($result)) {
                echo "<tr><td>".$row['no']."</td><td>".$row['description']."</td><td>".$row['area']."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No properties found for $ownerName.";
        }
    }
    pg_close($db);
    ?>
