<?php

$info = array(
    "1" => array("name"=>"abc","address"=>"pune","age"=>"20"),
    "2" => array("name"=>"def","address"=>"loni","age"=>"21"),
    "3" => array("name"=>"jkl","address"=>"ngo","age"=>"22")
);

$t1 = $_GET["inp2"];
$t2 = $_GET["string2"];
$t3 = $_GET["string1"];

if($t1 == 1)
{
    print_r($info[$t1]);
}
else
{
    print_r($info[$t2][$t3]);
}

?>

