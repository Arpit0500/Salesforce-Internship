<?php
$xml = simplexml_load_file("subject.xml") or die("Error: Cannot create object");

$target_name = "Web Technology Laboratory";
$subject_code = "";

foreach ($xml->subject as $subject) {
    if (trim($subject->subject_name) == $target_name) {
        $subject_code = $subject->subject_code;
        break; // Exit the loop once the subject is found
    }
}

if (!empty($subject_code)) {
    echo "The subject code for \"$target_name\" is: " . $subject_code;
} else {
    echo "Subject not found.";
}
?>
