<?php
$a=array("RAMESH","SURESH","RAJ","SEEMA","PUJA","SIYA","AJAY","SAMEER","VIJAY","VINAY","VIRAJ");

if(isset($_GET['search']))
{
    $q=$_GET['search'];

    if(strlen($q)>0)
    {
        $match="";

        for($i=0;$i<count($a);$i++)
        {
            if(strtolower($q)==strtolower(substr($a[$i],0,strlen($q))))
            {
                if($match=="")
                {
                    $match=$a[$i];
                }
                else
                {
                    $match=$match.", ".$a[$i];
                }
            }
        }

        if($match=="")
        {
            echo "No Suggestions";
        }
        else
        {
            echo "Suggestions: ".$match;
        }
    }
}
?>
