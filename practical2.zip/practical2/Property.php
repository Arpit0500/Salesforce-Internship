<?php

$host = "localhost";
$port = "5432";
$dbname = "postgres";
$user = "postgres";
$password = "Sarthak";   // put your real password here

$connection_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$dbconn = pg_connect($connection_string) or die(pg_last_error());

if ($dbconn) {

    echo "Connection to PostgreSQL successful!<br>";

    $nm = $_POST["Owner"];
    echo $nm . "<br>";

    $query = "SELECT * FROM properties WHERE Owner = $1";
    $result = pg_query_params($dbconn, $query, array($nm));

    if ($result) {

        while ($row = pg_fetch_row($result)) {

            echo "No: " . $row[0] .
                 " Type: " . $row[1] .
                 " Area: " . $row[2] .
                 " Owner: " . $row[3] . "<br>";
        }

        pg_free_result($result);

    } else {
        echo "Query failed: " . pg_last_error($dbconn);
    }

    pg_close($dbconn);

} else {
    echo "Connection failed.";
}

?>
