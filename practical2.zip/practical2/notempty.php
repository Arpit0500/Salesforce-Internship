<?php

$name1 = $_POST["Name1"];
$email1 = $_POST["Email1"];
$name2 = $_POST["Name2"];
$email2 = $_POST["Email2"];

if(empty($name1) || empty($email1) || empty($name2) || empty($email2))
{
    echo "One of the field is empty";
}
else
{
    if(filter_var($email1, FILTER_VALIDATE_EMAIL) && filter_var($email2, FILTER_VALIDATE_EMAIL))
    {
        echo "Name1 : ".$name1."<br>";
        echo "Email1 : ".$email1."<br>";
        echo "Name2 : ".$name2."<br>";
        echo "Email2 : ".$email2."<br>";
    }
    else
    {
        echo "Invalid";
    }
}

?>
