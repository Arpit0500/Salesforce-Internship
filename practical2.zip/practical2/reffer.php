<?php
if (isset($_POST['department_name']) && !empty($_POST['department_name'])) {
    $department_name = $_POST['department_name'];

    $host = 'localhost';
    $dbname = 'db1';
    $user = 'postgres';
    $password = 'Pass@word';
    $port = '5432'; // Default PostgreSQL port

    $conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
    
    $conn = pg_connect($conn_string);

    if (!$conn) {
        die("Connection failed: " . pg_last_error());
    }

    $query = "SELECT 
                MAX(e.salary) AS max_salary, 
                MIN(e.salary) AS min_salary, 
                SUM(e.salary) AS sum_salary
              FROM 
                emp e
              JOIN 
                dept d ON e.dno = d.dno
              WHERE 
                d.dname = $1
              GROUP BY
                d.dname";

    $result = pg_query_params($conn, $query, array($department_name));

    if (!$result) {
        echo "An error occurred during query execution: " . pg_last_error($conn);
        exit;
    }

    if (pg_num_rows($result) > 0) {
        $row = pg_fetch_assoc($result);
        
        echo "<h3>Department name: " . htmlspecialchars($department_name) . "</h3>";
        echo "<ul>";
        echo "<li>Maximum Salary: " . htmlspecialchars($row['max_salary']) . "</li>";
        echo "<li>Minimum Salary: " . htmlspecialchars($row['min_salary']) . "</li>";
        echo "<li>Sum of the Salary: " . htmlspecialchars($row['sum_salary']) . "</li>";
        echo "</ul>";
    } else {
        echo "<p>No data found for department: " . htmlspecialchars($department_name) . "</p>";
    }

    pg_free_result($result);
    pg_close($conn);

} else {
    echo "<p>Please enter a department name.</p>";
}
?>
<br>
<a href="index.html">Go Back to Form</a>
