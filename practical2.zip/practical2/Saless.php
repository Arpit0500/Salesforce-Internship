<?php
$servername = "localhost";
$username = "localhost"; // Replace with your database username
$password = "YES"; // Replace with your database password
$dbname = "your_database_name"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['order_date'])) {
    $input_date = $_POST['order_date'];
    $sql = "SELECT sonumber, s_order_date FROM Sales_order WHERE s_order_date < ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $input_date); // "s" indicates string type
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "<h1>Sales Orders Before " . htmlspecialchars($input_date) . "</h1>";
        echo "<table border='1'>";
        echo "<tr><th>Order Number</th><th>Order Date</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . htmlspecialchars($row["sonumber"]) . "</td><td>" . htmlspecialchars($row["s_order_date"]) . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "No sales orders found before " . htmlspecialchars($input_date) . ".";
    }
    
    $stmt->close();
} else {
    echo "Please submit a date using the form.";
}
$conn->close();
?>//save this as php

