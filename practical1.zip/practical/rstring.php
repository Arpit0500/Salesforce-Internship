<?php
$str = $_POST["string"];
$arr = str_split($str);

for($i = strlen($str)-1; $i >= 0; $i--)
{
echo $arr[$i];
}
?>