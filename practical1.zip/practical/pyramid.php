<?php
$i;
$j;

$rows = 5;
$ch = 'A';

for ($i = 0; $i < $rows; $i++)
{
    for ($j = $rows; $j > $i; $j--)
    {
        echo "&nbsp;";
    }

    for ($k = 0; $k < $i; $k++)
    {
        echo $ch . " ";
    }

    $ch++;
    echo "<br>";
}
?>