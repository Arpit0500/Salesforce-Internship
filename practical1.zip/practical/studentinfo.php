<?php

echo "Sarthak Rane <br>";

echo" 1015 <br>";

echo "College rame modern college pune

?>