<?php
$n = 5;
$pre = 0;
$cu = 1;

echo "Fibonacci series:<br>";
echo "0\t1\t";

for ($i = 0; $i < $n; $i++)
{
    echo $pre + $cu . "\t";
    $v = $pre + $cu;
    $pre = $cu;
    $cu = $v;
}
?>