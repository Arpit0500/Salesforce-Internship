<?php
$filePath = "C:/xampp/htdocs/practical/file.txt";

if (file_exists($filePath)) {

$fileName = basename($filePath);
$fileType = mime_content_type($filePath);

header("Content-Description: File Transfer");
header("Content-Type: ".$fileType);
header("Content-Disposition: attachment; filename=".$fileName);
header("Expires: 0");
header("Cache-Control: must-revalidate");
header("Pragma: public");
header("Content-Length: ".filesize($filePath));

ob_clean();
flush();

readfile($filePath);
exit;

}
else {
echo "Error: File not Found.";
}
?>