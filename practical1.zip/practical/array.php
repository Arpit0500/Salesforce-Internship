<?php
$info = array("Name"=>"Sarthak","Age"=>21,"Add"=>"Pune");

$opt = $_GET["m1"];

if($opt == 1)
{
print_r($info);
}
else
{
echo sizeof($info);
}
?>