<?php
$x = 10;
$y = 20;
$z = 30;

if ($x > $y && $x > $z) {
    echo $x . " is maximum";
}
elseif ($y > $x && $y > $z) {
    echo $y . " is maximum";
}
else {
    echo $z . " is maximum";
}
?>