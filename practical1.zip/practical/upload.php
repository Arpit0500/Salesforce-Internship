<?php

$file = $_FILES["fileToUpload"];

echo "File Name: ".$file["name"]."<br>";
echo "File Type: ".$file["type"]."<br>";
echo "File Size: ".$file["size"]."<br>";
echo "Temp Name: ".$file["tmp_name"];

?>