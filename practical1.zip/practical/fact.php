<?php
function fact($n1){
$n=1;
for($i=1;$i<=$n1;$i++)
{
$n=$n*$i;
}
echo "Factorial of ".$n1." is ".$n;
}

$n=$_POST["integer"];
fact($n);
?>

</body>
</html>