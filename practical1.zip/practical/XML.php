<?php
$dom = new DOMDocument("1.0","UTF-8");

$dom->formatOutput = true;

$abcCollege = $dom->createElement("ABC_College");
$dom->appendChild($abcCollege);

$compAppDept = $dom->createElement("Computer_Application_Department");
$abcCollege->appendChild($compAppDept);

$course = $dom->createElement("Course","BCA(Science)");
$compAppDept->appendChild($course);

$studentStrength = $dom->createElement("Student_Strength","80");
$compAppDept->appendChild($studentStrength);

$numTeachers = $dom->createElement("Number_of_Teachers","12");
$compAppDept->appendChild($numTeachers);

$xmlOutput = $dom->saveXML();

header("Content-Type: text/xml");

echo $xmlOutput;
?>